<?php

class Athomes extends Eloquent {

	protected $table = 'athomes';

	public static $accessible = array(
        
    );
}